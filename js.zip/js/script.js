let enviar = document.querySelector('#botao');
let musica = document.querySelector('#musica');
let artista = document.querySelector('#artista');
let info = document.querySelector('#info');
enviar.addEventListener('click', buscar);

function buscar(){
    info.innerHTML = '';

    axios.get(`https://api.lyrics.ovh/v1/${artista.value}/${musica.value}`)
    .then(function (response) {
        console.log(response);

        const letra = document.createElement('p');
        letra.innerHTML = response.data.lyrics;

        info.appendChild(letra);

    })
    .catch(function (error) {
      console.log(error);
      const err = document.createElement('p');
      err.innerHTML = 'Nenhum dado foi encontrado'
      info.appendChild(err);
      
    });


}