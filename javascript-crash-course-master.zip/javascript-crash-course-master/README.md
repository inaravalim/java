# Javascript Crash Course

Links that you can find more about Javascript

## Basics

https://gist.github.com/bmarchete/9fbd7f38c6121bfc9f708fd8ab3a51df

## DOM manipulation

https://gist.github.com/bmarchete/4007ee63c587ef1055c279881c799db2

### Codepen

https://codepen.io/bmarchete/pen/baGRdw

https://codepen.io/bmarchete/pen/LeYLEq

https://codepen.io/bmarchete/pen/aVPQgX


### Public APIs (no apy key needed)

https://api.github.com/

https://dog.ceo/dog-api/

lyricsovh.docs.apiary.io

https://api.github.com

https://api.chucknorris.io/



