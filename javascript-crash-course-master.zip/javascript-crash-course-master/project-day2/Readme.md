# Project Day 2

Try to build an App that retrieves data from an external API!

