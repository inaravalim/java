# Projeto do Primeiro dia


O projeto tinha como objetivo **Criar uma lista de metas/resoluções de ano novo. Utilizando apenas JavaScript para manipulação de DOM!**
