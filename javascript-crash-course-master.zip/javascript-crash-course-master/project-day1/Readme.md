# Project Day 1

Try to build an App that allows users insert and remove new year resolutions!

![Image](./image.png)
